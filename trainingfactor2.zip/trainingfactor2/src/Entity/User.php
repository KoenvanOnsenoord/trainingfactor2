<?php

namespace App\Entity;

use App\Repository\UserRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Bridge\Doctrine\Validator\Constraints\UniqueEntity;
use Symfony\Component\Security\Core\User\PasswordAuthenticatedUserInterface;
use Symfony\Component\Security\Core\User\UserInterface;

#[ORM\Entity(repositoryClass: UserRepository::class)]
#[UniqueEntity(fields: ['email'], message: 'There is already an account with this email')]
#[UniqueEntity(fields: ['email'], message: 'There is already an account with this email')]
class User implements UserInterface, PasswordAuthenticatedUserInterface
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(length: 180, unique: true)]
    private ?string $email = null;

    #[ORM\Column]
    private array $roles = [];

    /**
     * @var string The hashed password
     */
    #[ORM\Column]
    private ?string $password = null;

    #[ORM\Column(length: 255)]
    private ?string $firstname = null;

    #[ORM\Column(length: 255)]
    private ?string $preprovision = null;

    #[ORM\Column(length: 255)]
    private ?string $lastname = null;

    #[ORM\Column(type: Types::DATE_MUTABLE,  nullable:true)]
    private ?\DateTimeInterface $dateofbirth = null;

    #[ORM\OneToMany(mappedBy: 'user', targetEntity: Mededeling::class)]
    private Collection $mededelings;

    #[ORM\OneToMany(mappedBy: 'instructor', targetEntity: Lessen::class)]
    private Collection $lessens;

    #[ORM\OneToMany(mappedBy: 'klant', targetEntity: Lessen::class)]
    private Collection $Lessen2;

    public function __construct()
    {
        $this->mededelings = new ArrayCollection();
        $this->lessens = new ArrayCollection();
        $this->Lessen2 = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    /**
     * A visual identifier that represents this user.
     *
     * @see UserInterface
     */
    public function getUserIdentifier(): string
    {
        return (string) $this->email;
    }

    /**
     * @deprecated since Symfony 5.3, use getUserIdentifier instead
     */
    public function getUsername(): string
    {
        return (string) $this->email;
    }

    /**
     * @see UserInterface
     */
    public function getRoles(): array
    {
        $roles = $this->roles;
        // guarantee every user at least has ROLE_USER
        $roles[] = 'ROLE_USER';

        return array_unique($roles);
    }

    public function setRoles(array $roles): self
    {
        $this->roles = $roles;

        return $this;
    }

    /**
     * @see PasswordAuthenticatedUserInterface
     */
    public function getPassword(): string
    {
        return $this->password;
    }

    public function setPassword(string $password): self
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Returning a salt is only needed, if you are not using a modern
     * hashing algorithm (e.g. bcrypt or sodium) in your security.yaml.
     *
     * @see UserInterface
     */
    public function getSalt(): ?string
    {
        return null;
    }

    /**
     * @see UserInterface
     */
    public function eraseCredentials()
    {
        // If you store any temporary, sensitive data on the user, clear it here
        // $this->plainPassword = null;
    }

    public function getFirstname(): ?string
    {
        return $this->firstname;
    }

    public function setFirstname(string $firstname): self
    {
        $this->firstname = $firstname;

        return $this;
    }

    public function getPreprovision(): ?string
    {
        return $this->preprovision;
    }

    public function setPreprovision(string $preprovision): self
    {
        $this->preprovision = $preprovision;

        return $this;
    }

    public function getLastname(): ?string
    {
        return $this->lastname;
    }

    public function setLastname(string $lastname): self
    {
        $this->lastname = $lastname;

        return $this;
    }

    public function getDateofbirth(): ?\DateTimeInterface
    {
        return $this->dateofbirth;
    }

    public function setDateofbirth(\DateTimeInterface $dateofbirth): self
    {
        $this->dateofbirth = $dateofbirth;

        return $this;
    }

    /**
     * @return Collection<int, Mededeling>
     */
    public function getMededelings(): Collection
    {
        return $this->mededelings;
    }

    public function addMededeling(Mededeling $mededeling): self
    {
        if (!$this->mededelings->contains($mededeling)) {
            $this->mededelings->add($mededeling);
            $mededeling->setUser($this);
        }

        return $this;
    }

    public function removeMededeling(Mededeling $mededeling): self
    {
        if ($this->mededelings->removeElement($mededeling)) {
            // set the owning side to null (unless already changed)
            if ($mededeling->getUser() === $this) {
                $mededeling->setUser(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Lessen>
     */
    public function getLessens(): Collection
    {
        return $this->lessens;
    }

    public function addLessen(Lessen $lessen): self
    {
        if (!$this->lessens->contains($lessen)) {
            $this->lessens->add($lessen);
            $lessen->setInstructor($this);
        }

        return $this;
    }

    public function removeLessen(Lessen $lessen): self
    {
        if ($this->lessens->removeElement($lessen)) {
            // set the owning side to null (unless already changed)
            if ($lessen->getInstructor() === $this) {
                $lessen->setInstructor(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Lessen>
     */
    public function getLessen2(): Collection
    {
        return $this->Lessen2;
    }

    public function addLessen2(Lessen $lessen2): self
    {
        if (!$this->Lessen2->contains($lessen2)) {
            $this->Lessen2->add($lessen2);
            $lessen2->setKlant($this);
        }

        return $this;
    }

    public function removeLessen2(Lessen $lessen2): self
    {
        if ($this->Lessen2->removeElement($lessen2)) {
            // set the owning side to null (unless already changed)
            if ($lessen2->getKlant() === $this) {
                $lessen2->setKlant(null);
            }
        }

        return $this;
    }
}
