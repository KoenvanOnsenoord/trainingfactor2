<?php

namespace App\Entity;

use App\Repository\LessenRepository;
use Doctrine\DBAL\Types\Types;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: LessenRepository::class)]
class Lessen
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column]
    private ?int $id = null;

    #[ORM\Column(type: Types::DATE_MUTABLE)]
    private ?\DateTimeInterface $datum = null;

    #[ORM\Column(type: Types::TIME_MUTABLE)]
    private ?\DateTimeInterface $tijd = null;

    #[ORM\Column(length: 255)]
    private ?string $ophaallocatie = null;

    #[ORM\Column(length: 255)]
    private ?string $lesdoel = null;

    #[ORM\Column(length: 255)]
    private ?string $annuleren = null;

    #[ORM\Column(length: 255)]
    private ?string $annuleer_reden = null;

    #[ORM\Column(length: 255)]
    private ?string $opmerkingeninstructeur = null;

    #[ORM\Column(length: 255)]
    private ?string $opmerkingenleerling = null;

    #[ORM\ManyToOne(inversedBy: 'lessens')]
    private ?User $instructor = null;

    #[ORM\ManyToOne(inversedBy: 'Lessen2')]
    private ?User $klant = null;

    #[ORM\Column(length: 255)]
    private ?string $rol = null;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDatum(): ?\DateTimeInterface
    {
        return $this->datum;
    }

    public function setDatum(\DateTimeInterface $datum): self
    {
        $this->datum = $datum;

        return $this;
    }

    public function getTijd(): ?\DateTimeInterface
    {
        return $this->tijd;
    }

    public function setTijd(\DateTimeInterface $tijd): self
    {
        $this->tijd = $tijd;

        return $this;
    }

    public function getOphaallocatie(): ?string
    {
        return $this->ophaallocatie;
    }

    public function setOphaallocatie(string $ophaallocatie): self
    {
        $this->ophaallocatie = $ophaallocatie;

        return $this;
    }

    public function getLesdoel(): ?string
    {
        return $this->lesdoel;
    }

    public function setLesdoel(string $lesdoel): self
    {
        $this->lesdoel = $lesdoel;

        return $this;
    }

    public function getAnnuleren(): ?string
    {
        return $this->annuleren;
    }

    public function setAnnuleren(string $annuleren): self
    {
        $this->annuleren = $annuleren;

        return $this;
    }

    public function getAnnuleerReden(): ?string
    {
        return $this->annuleer_reden;
    }

    public function setAnnuleerReden(string $annuleer_reden): self
    {
        $this->annuleer_reden = $annuleer_reden;

        return $this;
    }

    public function getOpmerkingeninstructeur(): ?string
    {
        return $this->opmerkingeninstructeur;
    }

    public function setOpmerkingeninstructeur(string $opmerkingeninstructeur): self
    {
        $this->opmerkingeninstructeur = $opmerkingeninstructeur;

        return $this;
    }

    public function getOpmerkingenleerling(): ?string
    {
        return $this->opmerkingenleerling;
    }

    public function setOpmerkingenleerling(string $opmerkingenleerling): self
    {
        $this->opmerkingenleerling = $opmerkingenleerling;

        return $this;
    }

    public function getInstructor(): ?User
    {
        return $this->instructor;
    }

    public function setInstructor(?User $instructor): self
    {
        $this->instructor = $instructor;

        return $this;
    }

    public function getKlant(): ?User
    {
        return $this->klant;
    }

    public function setKlant(?User $klant): self
    {
        $this->klant = $klant;

        return $this;
    }

    public function getRol(): ?string
    {
        return $this->rol;
    }

    public function setRol(string $rol): self
    {
        $this->rol = $rol;

        return $this;
    }
}
