<?php

namespace App\Controller;

use App\Entity\Mededeling;
use App\Entity\Melding;
use App\Entity\Training;
use App\Entity\User;
use App\Form\MededelingType;
use App\Form\MeldingType;
use App\Form\UserEditType;
use App\Form\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdminController extends AbstractController
{
    #[Route('/admin', name: 'app_admin')]
    public function index(): Response
    {

        return $this->render('admin/index.html.twig', [
            'controller_name' => 'AdminController',
        ]);
    }
    #[Route('/admin/instructors', name: 'instructors')]
    public function instructorsAction(EntityManagerInterface $entityManager): Response
    {
        $users = $entityManager->getRepository(User::class)->findInstructor();


        return $this->render('admin/instructors.html.twig', [
            'controller_name' => 'AdminController',
            'users' => $users
        ]);
    }
    #[Route('/admin/userForm', name: 'adduser')]
    public function CreateUser(EntityManagerInterface $entityManager, Request $request): Response
    {
        $user = new User();

        $form = $this->createForm(UserType::class, $user);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
           $user->setRoles((array)'ROLE_INSTRUCTOR');
            $user = $form->getData();

            $entityManager->persist($user);
            $entityManager->flush();
            $this->addFlash(
                'success',
                'Nieuwe gebruiker toegevoegd.'
            );
            return $this->redirectToRoute('instructors');
        }
        return $this->renderForm('admin/userForm.html.twig', [
            'form' => $form,
        ]);
    }
    #[Route('/admin/instructors-edit/{id}', name: 'edituser')]
    public function editUser(Request $request, EntityManagerInterface $entityManager, int $id): Response
    {
        // just set up a fresh $task object (remove the example data)
        $user = $entityManager->getRepository(User::class)->find($id);

        $form = $this->createForm(UserEditType::class, $user);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $user = $form->getData();
            $entityManager->persist($user);
            $entityManager->flush();
            // ... perform some action, such as saving the task to the database

            return $this->redirectToRoute('instructors', ['id' => $id]);
        }

        return $this->renderForm('admin/edituserForm.html.twig', [
            'form' => $form,
        ]);
    }

    #[Route('delete-user/{id}', name: 'delete-user')]
    public function deleteUser(EntityManagerInterface $entityManager, int $id){
        $user = $entityManager->getRepository(User::class)->find($id);
        $entityManager->remove($user);
        $entityManager->flush();
        $this->addFlash(
            'danger',
            'Auto verwijderd.'
        );
        return $this->redirectToRoute('instructors');
    }

    #[Route('/create-melding', name: 'create-melding')]
    public function makeMelding(Request $request, EntityManagerInterface $entityManager): Response
    {
        $Mededeling = new Mededeling();

        $form = $this->createForm(MededelingType::class, $Mededeling);

        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()){
            $Mededeling = $form->getData();
            $Mededeling->setUser($this->getUser());
            $entityManager->persist($Mededeling);
            $entityManager->flush();
            $this->addFlash('success', 'De melding is aangemaakt');
            return $this->redirectToRoute('app_admin');
        }

        return $this->renderForm('admin/mededeling-form.html.twig', [
            'form' => $form
        ]);

    }

}
