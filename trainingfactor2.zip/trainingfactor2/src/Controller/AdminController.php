<?php

namespace App\Controller;

use App\Entity\Training;
use App\Entity\User;
use App\Form\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdminController extends AbstractController
{
    #[Route('/admin', name: 'app_admin')]
    public function index(): Response
    {

        return $this->render('admin/index.html.twig', [
            'controller_name' => 'AdminController',
        ]);
    }
    #[Route('/admin/instructors', name: 'instructors')]
    public function instructorsAction(EntityManagerInterface $entityManager): Response
    {
        $users = $entityManager->getRepository(User::class)->findInstructor();


        return $this->render('admin/instructors.html.twig', [
            'controller_name' => 'AdminController',
            'users' => $users
        ]);
    }
    #[Route('/admin/userForm', name: 'adduser')]
    public function CreateUser(EntityManagerInterface $entityManager, Request $request): Response
    {
        $user = new User();

        $form = $this->createForm(UserType::class, $user);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
           $user->setRoles((array)'ROLE_INSTRUCTOR');
            $user = $form->getData();

            $entityManager->persist($user);
            $entityManager->flush();
            $this->addFlash(
                'success',
                'Nieuwe gebruiker toegevoegd.'
            );
            return $this->redirectToRoute('instructors');
        }
        return $this->renderForm('admin/userForm.html.twig', [
            'form' => $form,
        ]);
    }

}
