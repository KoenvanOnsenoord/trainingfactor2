<?php

namespace App\Controller;

use App\Entity\Mededeling;
use App\Entity\Melding;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class InstructorController extends AbstractController
{
    #[Route('/instructor', name: 'app_instructor')]
    public function index(EntityManagerInterface $entityManager): Response
    {
        $meldingen = $entityManager->getRepository(Mededeling::class)->findBy(['rol' => 'instructor']);
        return $this->render('instructor/index.html.twig', [
            'controller_name' => 'InstructorController',
            'meldingen' => $meldingen
        ]);
    }
}
