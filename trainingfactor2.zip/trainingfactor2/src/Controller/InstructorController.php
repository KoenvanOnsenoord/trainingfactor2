<?php

namespace App\Controller;

use App\Entity\Lessen;
use App\Entity\Mededeling;
use App\Entity\Melding;
use App\Entity\Training;
use App\Entity\User;
use App\Form\ChangeLesType;
use App\Form\UserEditType;
use App\Form\UserType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class InstructorController extends AbstractController
{
    #[Route('/instructor', name: 'app_instructor')]
    public function index(EntityManagerInterface $entityManager): Response
    {
        $meldingen = $entityManager->getRepository(Mededeling::class)->findBy(['rol' => 'instructor']);
        return $this->render('instructor/index.html.twig', [
            'controller_name' => 'InstructorController',
            'meldingen' => $meldingen
        ]);
    }
    #[Route('/instructor/training', name: 'training')]
    public function showLessen(EntityManagerInterface $entityManager): Response
    {
        $lessen = $entityManager->getRepository(Lessen::class)->findAll();

        return $this->render('instructor/training.html.twig', [
            'lessen' => $lessen
        ]);
    }

    #[Route('/instructor/detail/{id}', name: 'detail')]
    public function detail(EntityManagerInterface $entityManager, int $id): Response
    {
        $lessen = $entityManager->getRepository(Lessen::class)->find($id);

        return $this->render('instructor/detail.html.twig', [
            'lessen' => $lessen

        ]);
    }

    #[Route('/instructor/lessen-edit/{id}', name: 'editles')]
    public function editLes(Request $request, EntityManagerInterface $entityManager, int $id): Response
    {
        // just set up a fresh $task object (remove the example data)
        $lessen = $entityManager->getRepository(Lessen::class)->find($id);

        $form = $this->createForm(ChangeLesType::class, $lessen);

        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $lessen = $form->getData();
            $entityManager->persist($lessen);
            $entityManager->flush();
            // ... perform some action, such as saving the task to the database

            return $this->redirectToRoute('instructors', ['id' => $id]);
        }

        return $this->renderForm('instructor/editlessenForm.html.twig', [
            'form' => $form,
        ]);
    }
    #[Route('/instructor/userForm', name: 'addles')]
    public function CreateUser(EntityManagerInterface $entityManager, Request $request): Response
    {
        $lessen = new Lessen();

        $form = $this->createForm(UserType::class, $lessen);
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {
            $lessen->setRoles((array)'ROLE_KLANT');
            $lessen = $form->getData();

            $entityManager->persist($lessen);
            $entityManager->flush();
            $this->addFlash(
                'success',
                'Nieuwe gebruiker toegevoegd.'
            );
            return $this->redirectToRoute('instructors');
        }
        return $this->renderForm('instructor/addlesForm.html.twig', [
            'form' => $form,
        ]);
    }
}
