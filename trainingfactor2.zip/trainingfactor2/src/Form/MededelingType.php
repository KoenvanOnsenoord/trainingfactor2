<?php

namespace App\Form;

use App\Entity\Mededeling;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class MededelingType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('datum')
            ->add('titel')
            ->add('inhoud');
            $builder->add('rol', ChoiceType::class, [
                    'choices' => [
                        'Instructeur' => 'instructor',
                        'kant' => 'klant',
                    ],
                
            ])
        ->add('save', SubmitType::class, ['label' => 'Mededeling maken']);

    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Mededeling::class,
        ]);
    }
}
